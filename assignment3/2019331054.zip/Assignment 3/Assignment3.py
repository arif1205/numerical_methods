import tkinter as tk
import Gui_Regression as erk
import Interpolation as intg
root = tk.Tk()
root.title("Solve function for given ddx")
root.geometry('400x300')
arial = ('arial', 20)

def regression():
    erk.run()
def interpolation():
    intg.run()
tk.Label(root, text='\n', font = arial).pack()
tk.Button(root, text = 'Interpolation', font = arial, command = interpolation).pack(pady = 10)
tk.Button(root, text = 'Regression Model', font = arial, command = regression).pack(pady =1)


root.mainloop()