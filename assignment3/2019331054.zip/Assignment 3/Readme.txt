$ pip install requirements.txt

then,
Run Assignment3.py only


$ python3 -u Assignment3.py
or
$ py -u Assignment3.py
